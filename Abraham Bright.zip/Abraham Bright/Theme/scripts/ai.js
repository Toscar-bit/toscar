// Jargons © 2019 - (SAT Networks) 
sessionStorage.setItem("fc", "#4284d5")
sessionStorage.setItem("sc", "#204D7E")
class Background {
    constructor(dx, dy, Srect, Sround, Shalf, SroundHalf, FText) {
        this.dx = dx; this.dy = dy; this.Srect = Srect; this.SroundHalf = SroundHalf; this.Sround = Sround; this.Shalf = Shalf; this.FText = FText;
    }

    dimension(type) {
    //     // Sessions as storage to recieve dms
    //     var dimens = sessionStorage.getItem("dimensions");
    //     if (dimens == "mt") {
    //         this.dx = 250;
    //         this.dy = 250;
    //     } if (dimens == "mo") {
    //         this.dx = 300;
    //         this.dy = 250;
    //     } if (dimens == "mtt") {
    //         this.dx = 300;
    //         this.dy = 200;
    //     } if (dimens == "mf") {
    //         this.dx = 300;
    //         this.dy = 180;
    //     }

        this.dx = 250;
        this.dy = 250;
        var dimension = new Array(this.dx, this.dy); // Dimensions
        if (type == "x") { // x, y as parameters
            return dimension[0];
        }

        if (type == "y") {
            return dimension[1];
        }
    }

    // Bstyle(){
    //     var bstyleDimensionX = this.dimension("x");
    //     var bstyleDimensionY = this.dimension("y");

    //     // Compute dimensions to Bstyle
    //     bstyleDimensionX = 90 * bstyleDimensionX / 100 / 1;
    //     bstyleDimensionY = 90 * bstyleDimensionY / 100 / 1;

    //     //Margins
    //     var margX = (this.dimension("x") - bstyleDimensionX) / 2;
    //     var margY = (this.dimension("y") - bstyleDimensionY) / 2;

    //     // Srect
    //     this.Srect = "/*width:"+bstyleDimensionX+"px; height:"+bstyleDimensionY+"px;*/ border: 1px solid black; transform: translateX("+margX+"px) translateY("+margY+"px);";

    //     // Sround
    //     var SroundCurve = this.Radius(1);
    //     this.Sround = "width:"+bstyleDimensionX+"px; height:"+bstyleDimensionY+"px; border: 1px solid black; transform: translateX("+margX+"px) translateY("+margY+"px); border-radius:"+SroundCurve+"px;";

    //     // Shalf
    //     var sliceY = this.randSlice();
    //     this.Shalf = "width:"+bstyleDimensionX+"px; height:"+sliceY+"px; border: 1px solid black; transform: translateX("+margX+"px) translateY("+margY+"px);";

    //     // SroundHalf

    //     this.SroundHalf = "width:"+bstyleDimensionX+"px; height:"+sliceY+"px; border: 1px solid black; transform: translateX("+margX+"px) translateY("+margY+"px); border-radius:"+SroundCurve+"px;";

    //     // Background styles packed as bstyle
    //     var bstyle = new Array(this.Srect, this.Sround, this.Shalf, this.SroundHalf);
    //     var cursor = Math.floor(Math.random() * bstyle.length);
    //     return bstyle[cursor];
    // }

    // randSlice(){
    //     var actualHeight = this.dimension("y");
    //     // randomize slice in 10 terms
    //     var sq, sw, se, sr, st, sy, su, si, so, sp, sj, sk;
    //     sq = (40 * actualHeight) / 100 / 1;
    //     so = (45 * actualHeight) / 100 / 1;
    //     sw = (50 * actualHeight) / 100 / 1;
    //     se = (60 * actualHeight) / 100 / 1;
    //     sr = (65 * actualHeight) / 100 / 1;
    //     sk = (85 * actualHeight) / 100 / 1;
    //     st = (70 * actualHeight) / 100 / 1;
    //     sj = (80 * actualHeight) / 100 / 1;
    //     su = (75 * actualHeight) / 100 / 1;
    //     sp = (55 * actualHeight) / 100 / 1;
    //     si = (90 * actualHeight) / 100 / 1;
    //     sy = (73.5 * actualHeight) / 100 / 1;

    //     var cuts = new Array(sq, sw, se, sr, st, sy, su, si, so, sp);
    //     var cursor = Math.floor(Math.random() * cuts.length);

    //     return cuts[cursor];
    // }

    Radius(responsibility) {
        if (responsibility == 1) {
            // No random returns
            var radius = Math.floor(Math.random() * 15);
            return radius;
        }

        if (responsibility == 0) {
            // Enable random returns
        }
    }

    Text() {
        // Number of Text blocks
        // var tbs = sessionStorage.getItem("tbs");

        // Functs
        // if (tbs == 1 || tbs == 2 || tbs == 3) {
            // Get texts
            // var textOne = sessionStorage.getItem("ad");
            // return textOne;
        // }
    }

    productName(){
        // var tbs = sessionStorage.getItem("tbs");
        // if (tbs == 2 || tbs == 3) {
        //     var pname = sessionStorage.getItem("prodname")
        //     return pname;
        // }
    }

    Lagorns(){
        // var tbs = sessionStorage.getItem("tbs");
        // if (tbs == 3) {
        //     var lagorns = sessionStorage.getItem("label");
        //     return lagorns;
        // }
    }

    Targon(){
        // var tbs = sessionStorage.getItem("tbs");
        // if (tbs == 3 || tbs == 2) {
        //     var Tagorn = sessionStorage.getItem("tag");
        //     return Tagorn;
        // }
    }

    tBack() {
        var tback = "width:" + this.dimension("x") + "px; height:" + this.dimension("y") + "px; ";

        return tback;
    }

    sTyle() {
        // Rand-talign - center match-parent end left right justify start and absence of value
        var text_align = new Array("center", "center", "center", "left", "left", "right", "right");
        var cursorTA = " text-align:" + text_align[Math.floor(Math.random() * 3)] + ";";

        // Rand-tdecoration - underline overline line-through none
        var text_decoration = new Array("none", "none", "none", "underline", "overline", "line-through");
        var cursorTD = " text-decoration:" + text_decoration[Math.floor(Math.random() * 6)] + ";";

        // Rand-ttransform - capitalize lowercase uppercase none
        var text_transform = new Array("none", "none", "capitalize", "capitalize", "lowercase",  "uppercase");
        var cursorTT = " text-transform:" + text_transform[Math.floor(Math.random() * 5)] + ";";

        // Rand-fontstyle -const
        var fontStyle = new Array("normal", "normal", "normal", "italics", "italics", "oblique");
        var cursor_FS = Math.floor(Math.random() * 5);
        var cursor_FS = "font-style: " + fontStyle[cursor_FS] + ";";

        // Rand-fontweight - inp
        var fw = new Array("250", "500", "750", "700", "750", "850", "900",)
        var cursFW = " font-weight: " + fw[Math.floor(Math.random() * 7)] + ";";

        // Rand-shadow - inp
        var text_shadow_x = new Array("null", "null", "null","0", "3", "5", "5", "6", "null", "null", "null", "null");
        var text_shadow_y = new Array("null", "null", "null","0", "3", "5", "5", "6", "null", "null", "null", "null"); 

        var text_shadow_color = new Array("#666", "#555");

        var curs_text_shadow_x = text_shadow_x[Math.floor(Math.random() * 12)];
        var curs_text_shadow_y = text_shadow_y[Math.floor(Math.random() * 12)];
        // var curs_text_shadow_neetive = text_shadow_neetive[Math.floor(Math.random()*6)]; impl -> box
        var textBlur = new Array(25, 30, 35, 40, 45, 50);
        var curs_text_shadow_blur = textBlur[Math.floor(Math.random() * 6)];
        if (curs_text_shadow_blur < 10) {
            curs_text_shadow_blur = 15;
        }
        var curs_text_shadow_color = text_shadow_color[Math.floor(Math.random() * 3)];

        if (curs_text_shadow_x == 'undefined') {
            curs_text_shadow_x = 0;
        }

        if (curs_text_shadow_y == 'undefined') {
            curs_text_shadow_y = 0;
        }


        if (curs_text_shadow_blur == 'undefined') {
            curs_text_shadow_blur = 0;
        }

        // if (text_shadow_neetive == undefined) {
        //     curs_text_shadow_neetive = 0;
        // } impl -> box

        if (curs_text_shadow_color == 'undefined') {
            curs_text_shadow_color = "#777";
        }


        var cursorTS = " text-shadow: " + curs_text_shadow_x + "px " + curs_text_shadow_y + "px " + curs_text_shadow_blur + "px " + curs_text_shadow_color + ";";


        // Fonts
        var fonts = new Array('Segoe UI', "Verdana", 'Segoe UI', "Verdana", "Tahoma", "Ametha", "Brandon", "figno", "Fitalia", "Fritch", "hansel-rough",  "loja", "manila-sans", "manila-sans", "manila-sans", "manila-sans", "manila-sans", "manila-sans", "margaret", "nelphilm-font", "tabitha", "vervelle");
        var cursorTF = " font-family: " + fonts[Math.floor(Math.random() * 22)] + ";"

        return cursorTA + cursorTD + cursorTT + cursorTS + cursorTF + cursFW + cursor_FS;
    }


    tStyle() {
        var textOne = "The quick brown fox jumps over the lazy dog"
     

            if (textOne.length <= 10 && textOne.length > 0) {
                var fontSize = "font-size: 350%;";
            }

            if (textOne.length <= 20 && textOne.length > 10) {
                var fontSize = "font-size: 280%; color: red;";
            }

            if (textOne.length <= 30 && textOne.length > 20) {
                var fontSize = "font-size: 245%;";
            }

            if (textOne.length <= 40 && textOne.length > 30) {
                var fontSize = "font-size: 210%;";
            }

            if (textOne.length <= 50 && textOne.length > 40) {
                var fontSize = "font-size: 175%;";
            }

            if (textOne.length <= 60 && textOne.length > 50) {
                var fontSize = "font-size: 140%;";
            }

            if (textOne.length <= 70 && textOne.length > 60) {
                var fontSize = "font-size: 130%;";
            }

            if (textOne.length <= 80 && textOne.length > 70) {
                var fontSize = "font-size: 120%;";  // Font as 70 decreases 
            }

        var textStyle = fontSize + " border: 1px solid black; float: right; width:100%; word-wrap: break-word;" + this.sTyle();

        return textStyle;
    }

    mid() {
        // fLEX
        var middle = new Array("display: flex; align-items: center; justify-content: center;")
        var cursMD = middle[Math.floor(Math.random() * 0)]; // Enable inexistence 4'
        return cursMD
    }

    scaleTorso() {
        var scto = new Array( "transform: none;", "transform: scale(0.95);", "transform: scale(0.9);", "transform: none;");
        var cursST = scto[Math.floor(Math.random() * 2)];
        return cursST;
    }

    borderStyle() {
        // Border bounds 1/4, 2/4, 3/4, 4/4
        var bBounds = new Array("1/4", "2/4", "3/4", "4/4", "blah blah", "blah blah");
        var cbBounds = bBounds[Math.floor(Math.random() * 5)]; // Border bounds cursor || Returns bound type
        var cColor = sessionStorage.getItem("stcborder");
        var cColori = sessionStorage.getItem("stcborderi");
        var cColorii = sessionStorage.getItem("stcborderii");
        var border = new Array(cColor, cColori, cColorii);
        cColor = border[Math.floor(Math.random()) * 3];
        var cbColor;
        // From bounds - border pos-type
        if (cbBounds == "1/4") {
            var bPype = new Array("border-top:", "border-left:", "border-right:", "border-bottom:"); // prefixes for b->
            var curs_sel_brd_i = bPype[Math.floor(Math.random() * 4)]; // 1/4

            // Border color -from user sugg 
            cbColor = cColor;
            // Border type
            // var bType = " "

            var cbType = "solid";
            // Border width
            var bWidth = Math.floor(Math.random() * 5) + "px"; // !px
            return curs_sel_brd_i + " " + bWidth + " " + cbType + " " + cbColor + ";";
        }

        if (cbBounds == "2/4") {
            var bPypeR = new Array("border-top:", "border-left:", "border-right:", "border-bottom:"); // prefixes for b->
            var cursPr = bPypeR[Math.floor(Math.random() * 4)];
            var cursP = bPypeR[Math.floor(Math.random() * 4)];
            //Check if same

            // Border color -from user sugg
            cbColor = cColor;
            // Border type

             var cbType = "solid";
            // Border width
            var bWidth = 3 + "px"; // !px
            return cursPr + " " + bWidth + " " + cbType + " " + cbColor + "; " + cursP + " " + bWidth + " " + cbType + " " + cbColor + ";" + bradius;

        }

        if (cbBounds == "3/4") {
            var bPype = new Array("border-top:", "border-left:", "border-right:", "border-bottom:"); // prefixes for b->

            var cursL, cursR, cursT;
            cursL = bPype[Math.floor(Math.random() * 4)];
            cursR = bPype[Math.floor(Math.random() * 4)];
            cursT = bPype[Math.floor(Math.random() * 4)];

            // Border color -from user sugg
            cbColor = cColor;
            // Border type
            var cbType = "solid";
            // Border width
            var bWidth = Math.floor(Math.random() * 5) + "px"; // !px

            return cursL + " " + bWidth + " " + cbType + " " + cbColor + "; " + cursR + " " + bWidth + " " + cbType + " " + cbColor + "; " + cursT + " " + bWidth + " " + cbType + " " + cbColor;
        }

        if (cbBounds == "4/4") {

            // Border color -from user sugg
            cbColor = cColor;
            // Border type
            var cbType = "solid";
            // Border width
            var bWidth = Math.floor(Math.random() * 5) + "px"; // !
            var bradius = "border-radius: 5px;";
            return "border: " + bWidth + " " + cbType + " " + cbColor + ";" + bradius;
        }

    }

    tagLinePos() {
        var tagPos = new Array("center", "left", "right", "justify");
        return "text-align: " + tagPos[Math.floor(Math.random() * 4)] + ";";

    }

    InnerBRadius() {
        var bradius = "border-radius: " + Math.floor(Math.random() * 5) + "px;"
        return bradius;
    }

    DivShad() {
        // Rand-shadow - inp
        var text_shadow_x = new Array("0", "3", "3", "3", "3");
        var text_shadow_y = new Array("0", "3", "3", "3", "3");
        var text_shadow_neetive = new Array("-10", "-15", "-20", "-25", "-30", "-35", "-40"); // impl -> box
        var text_shadow_color = new Array("#555", "#666");

        var curs_text_shadow_x = text_shadow_x[Math.floor(Math.random() * 6)];
        var curs_text_shadow_y = text_shadow_y[Math.floor(Math.random() * 6)];
        var curs_text_shadow_neetive = text_shadow_neetive[Math.floor(Math.random() * 6)]; //impl -> box
        var curs_text_shadow_blur = Math.floor(Math.random() * 50);
        if (curs_text_shadow_blur < 5) {
            curs_text_shadow_blur = 10;
        }
        var curs_text_shadow_color = text_shadow_color[Math.floor(Math.random() * 2)];

        if (curs_text_shadow_x == 'undefined') {
            curs_text_shadow_x = 0;
        }

        if (curs_text_shadow_y == 'undefined') {
            curs_text_shadow_y = 0;
        }


        if (curs_text_shadow_blur == 'undefined') {
            curs_text_shadow_blur = 0;
        }

        if (text_shadow_neetive == 'undefined') {
            curs_text_shadow_neetive = 0;
        } //impl -> box

        if (curs_text_shadow_color == 'undefined') {
            curs_text_shadow_color = "#777";
        }


        return " box-shadow: " + curs_text_shadow_x + "px " + curs_text_shadow_y + "px " + curs_text_shadow_blur + "px " + curs_text_shadow_neetive + "px " + curs_text_shadow_color + ";";
    }


    colorTheme(target) {
        var firsColor, secoColor;
        firsColor = sessionStorage.getItem("fc");
        secoColor = sessionStorage.getItem("sc");

        // var themeBackground = Array("canvas", "overlay", "text-background");

        if (target == "overlay") {
            var colorA, colorC;

            if (target == "overlay" && firsColor == "#ffffff" || secoColor == "#ffffff") {
                if (firsColor == "#ffffff") {
                    colorA = Array(secoColor, "#444444");
                    colorC = colorA[Math.floor(Math.random() * 2)];
                    sessionStorage.setItem("stcborder", colorC);
                    return "background-color: #ffffff; color: " + colorC + " ;";
                } else {
                    colorA = Array(firsColor, "#444444");
                    colorC = colorA[Math.floor(Math.random() * 2)];
                    sessionStorage.setItem("stcborder", colorC);
                    return "background-color: #ffffff; color: " + colorC + "; ";
                }

            } else {
                var colorCO = Array(firsColor, secoColor);
                var colorOC = colorCO[Math.floor(Math.random() * 2)]

                if (colorOC == firsColor) {
                    var background = Array(firsColor, "#ffffff");
                    var bgsel = background[Math.floor(Math.random() * 2)];
                    if (bgsel == "#ffffff") {
                        var randAn = Array(secoColor, firsColor);
                        color = randAn[Math.floor(Math.random() * 2)];
                    } else {
                        var rand = Array(secoColor, "#ffffff");
                        var color = rand[Math.floor(Math.random() * 2)]
                    }
                    if (bgsel == color) {
                        color = "#ffffff";
                    }
                    sessionStorage.setItem("stcborder", color);
                    return "background: " + bgsel + "; color: " + color + "; ";
                } else {
                    var rand = Array(firsColor, "#ffffff");
                    var color = rand[Math.floor(Math.random() * 2)]
                    sessionStorage.setItem("stcborder", color);
                    var background = Array(secoColor, "#ffffff");
                    var bgsel = background[Math.floor(Math.random() * 2)];

                    if (bgsel == "#ffffff") {
                        var randAn = Array(secoColor, firsColor);
                        color = randAn[Math.floor(Math.random() * 2)];
                    } else {
                        var rand = Array(secoColor, "#ffffff");
                        var color = rand[Math.floor(Math.random() * 2)]
                 }

                    if (bgsel == color) {
                        color = "#ffffff";
                    }
                    sessionStorage.setItem("stcborder", color);
                    sessionStorage.setItem("stcborderii", bgsel);
                    return "background: " + bgsel + "; color: " + color + "; ";
                }
            }
        }

        if (target == "canvas" && firsColor != "#ffffff" && secoColor != "#ffffff") {
            var grad;
            var canvasColor = Array(firsColor, secoColor, firsColor, secoColor, grad);
            var ccolor = canvasColor[Math.floor(Math.random() * 5)];
            if (ccolor == grad) {
                var gradie = Array("linear-gradient: ", "radial-gradient: ");
                var gradi = gradie[Math.floor(Math.random()*2)];
                if (gradi == "linear-gradient: ") {
                    return "background: linear-gradient("+firsColor+", "+secoColor+");";
                } else{
                    return "background: radial-gradient("+firsColor+", "+secoColor+");"
                }  
            }
            sessionStorage.setItem("stcborderi", ccolor);
            return "background-color: " + ccolor + ";"
        } // Canvas is random but not white!

        if (target == "canvas" && firsColor == "#ffffff" || secoColor == "#ffffff") {
            if (firsColor == "#ffffff") {
                return "background-color: " + secoColor + ";"
            } else {
                return "background-color: " + firsColor + ";"
            } // Canvas will not be white
        }

    }

    ctrlDis(){
        var tbs = sessionStorage.getItem("tbs");
        
        if (tbs == 1) {
            return "display: none; ";
        } else{
            return ""
        } 
    }

    ctrlDit(){
        var tbs = sessionStorage.getItem("tbs");
        
        if (tbs == 2) {
            return "display: none; ";
        } else{
            return ""
        }  
    }

    
    elementAnimation(){
        // Position along canvas axis
        // Style animation or alteration
        // Transitions between ad objects
        // Alteration of canvas elements
      }
}

let adBg = new Background();

var xwidth = adBg.dimension("x");
var yheight = adBg.dimension("y");
var main = adBg.Text();
var pname = adBg.productName();
var label = adBg.Lagorns();
var tag = adBg.Targon();

for (i = 0; i < 1; i++) {
    $("<div class='bg' style='width:" + xwidth + "px; " + adBg.colorTheme("canvas") + "  padding: 5px;   box-sizing: content-box; height:" + yheight + "px;'><div style='width:max-content; height:max-content'><div id='textt' style='" + adBg.tBack() + " " + adBg.scaleTorso() + "; " + adBg.InnerBRadius() + " " + adBg.DivShad() + " " + adBg.colorTheme("overlay") + "'><div class='prodname' style='font-size: 12px; position: relative; top: 3px; "+ adBg.tagLinePos() + " width:90%; left: 5%; "+adBg.ctrlDis()+"'>AD</div><div class='textcanvas' style='width:" + xwidth + "px; " + adBg.tStyle() + "; height:" + 80 * yheight / 100 / 1 + "px; overflow:hidden; " + adBg.mid() + "; border:none; padding: 5px; box-sizing: border-box;'><span style='transform: scale(0.9); padding: 10px; box-sizing: border-box;" + adBg.borderStyle() + "'> The quick brown fox jumps over the lazy dog. </span></div><div id='tg' style='font-size: 12px; " + adBg.tagLinePos() + " width:90%; position: relative; left: 5%; "+adBg.ctrlDis()+"'>Sample tagline</div></div><div class='brandname' style='font-size: 13px;  width:100%; position: relative; "+adBg.ctrlDis()+" top: 10px; "+adBg.ctrlDit()+"'><div id='nogo'><img src='iconion/tweet.png' alt=''>Sample label</div></div></div></div>").appendTo("body");
}

console.log("Project Analysis:");
console.log(" ");
console.log("---- VLE ------ Autonomous Systems -----------------------------------------------");
console.log("(Aa. Include the fonts[/Theme/Fonts] to the program [/Theme/scripts/ai.js && /Theme/theme.htm ])");
console.log("(Bb. Include the fonts with the CSS native method to retrieve a font file from a directory -> [/Theme/theme.htm])");
console.log("(Cc. Append the font name in the array variable -> [/Theme/scripts/ai.js] at the last section of code in the sTyle())");
console.log("(Dd. Repeat these steps until all fonts has been included)");